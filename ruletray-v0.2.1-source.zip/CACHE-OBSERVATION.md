# 本地缓存观察（可选）

`tools/cache_observer.py` 是标准库实现的只读观察器，与菜单和规则切换独立。不发模型请求、不接触凭据、不改Codex私有配置或数据库，不要求新增规范内容；仅读取用户授权项目的本机会话日志。通用源码不内置个人路径、任务名和会话。它依赖当前Codex日志结构，其他客户端需要另写经核验的数据适配器。

安装Agent准备私有JSON配置：`project_root`、`log_roots`（sessions与可选archived_sessions目录）、`scan_created_since`（日志创建日期下界）、`history_start`、`observation_start`、`observation_end`（带时区ISO时间）、`output_dir`、`interval_seconds`（默认600）、`utc_offset_hours`。可选`thread_labels`以会话ID映射`title`和`task`，仅代表人工历史归类；`task_names`是显示名映射。不要发布私有配置、采样或报告。

Agent使用Python运行`tools/cache_observer.py CONFIG --watch --open`。为用户创建指向pythonw的双击快捷方式即可；用户无需CLI。一次采样省略`--watch`。进程最多运行至配置结束时间；无自动开机启动，重开后从保留的原始日志重新去重补算。需要提前停止可在输出目录新建`STOP`空文件；恢复前由Agent移走该标志。不要直接删除日志来节省空间。

程序每轮重扫限定日期文件，不逐条保存聊天正文；只输出响应ID、会话ID、时间、模型、任务证据、规范文本指纹和token计数。输出`responses.json`、`summary.json`、`report.md`、本地`dashboard.html`、`status.json`和分时快照。输出仍属于私人使用元数据。文件锁避免两份观察器同时写入；状态文件记录进程和更新时间，快照保留当时汇总。断行稍后重读；坏行、缺字段、排除自动审批子代理等均有计数。没有结构化usage时标不可观测，绝不把缺失当零缓存。

客户端加载探针、性能试跑等非真实学习对话，在私有`thread_labels`对应项设置`purpose: "validation"`。仍保留实际用量及总体统计，但排除真实短任务样本和提升比较；不能用“问当前任务是什么”的短探针冒充讲题/练习效果。改观察器代码后重启后台实例才能生效，保留原观察窗口并从日志补算。

只计`token_usage_record.payload.usage`，按`response_id`去重；不加总`thread_token_usage`/`turn_token_usage`或重复token_count事件。缓存占比是Σcached_input_tokens/Σinput_tokens。新对话首请求、每任务/日期/模型/规则指纹、当前≤2个root_turn的短对话分别列出。首请求是扫描范围内可观测的最早响应，原始日志缺失不能证明真首次；旧日期创建且未轮转的会话不在范围。root_turn不等于已验证的用户消息计数，活跃对话后来变长会退出短任务组。

任务识别只从用户角色的项目AGENTS注入包装中读取现有`## Active task: ID`；无法找到时保留未知或带人工历史证据的标签，不读当前磁盘选项去倒推旧会话。文本指纹不是服务端token前缀证据。首请求同任务同模型才展示观察差异，按新规范版本分组并保留旧指纹；样本量和未缓存输入中位数同时显示。这不是随机配对实验，时段、题目长度和旧规范不同可能解释差异，不提供因果保证。

两三天验收：正常选任务→同项目新对话→完成一两轮任务。无需为了统计改用户提示或重复烧额度。各常用任务积累多条真实样本；模型尽量相同。记录是否加载正确规范、是否额外读规范、答案和笔记质量。数据不足就延长观察，不编提升值。没有缓存字段的客户端只验证文件一致与加载，不宣称缓存改善。

官方字段和缓存限制参考：[OpenAI Prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching)。本地日志字段名称与API字段可能不同，当前实现按实际日志核验。输入缓存率不等于订阅额度节省；本工具不控制服务端缓存边界、保留或调度。不自动上传、提交或发布。
