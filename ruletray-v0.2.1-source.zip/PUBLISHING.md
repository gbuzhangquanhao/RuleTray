# 上传准备与复核

公开名称为RuleTray，建议仓库名ruletray。这是源码发布包，不是已发布的GitHub仓库，也不是用户直接安装的exe。仓库拥有者和远程地址由发布者确定，不在包中预填；内部Python包名保留agent-task-router以兼容既有安装。

发布前：确认未解决问题已注明、版本说明与当前源码一致。首个公开预览版可以在真实使用观察期间发布；没有可靠提升证据就明确“缓存收益未确立”，不要用历史长对话缓存占比作产品提升。两天后复盘并提交实际结果，样本不足或效果不明显也如实报告。是否发布由拥有者决定，本项目没有自动发布动作。

网页上传方式：解压源码ZIP，把其中README.md、pyproject.toml等文件和agent_task_router、examples、tests、tools目录放在仓库根目录。不要只把ZIP作为唯一源码提交，也不要上传整个个人工作区。若发GitHub Release，可另将已核验源码ZIP作为附件；建议标签v0.2.1，标题RuleTray v0.2.1 — First Public Preview，勾选This is a pre-release；正文使用RELEASE-NOTES.md并按最终观察结果补全。无需用户运行CLI。

创建空仓库时，不额外生成README、gitignore或许可证，源码包已包含它们。第一次提交说明可写“Initial public preview of RuleTray”。提交后根目录应直接显示README.md和agent_task_router/，不多套一层解压目录。参考[创建仓库](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)、[网页上传](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)、[创建Release](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)。

两天后的普通文档或数据更新可提交到同一仓库。若发布新的可下载版本，更新版本号并创建新标签；不覆盖已发布的旧版ZIP或移动旧标签。第二次提交不要求另建仓库，也不必每次提交都创建Release。

维护Agent可运行`python tools/build_release.py OUTPUT.zip`重新生成白名单包。相同源码、同Python/压缩库环境输出可复现；ZIP条目时间固定，不含本机路径。重新核对ZIP实际文件清单、摘要和解压后测试，不能只检查.gitignore。不要在打包目录混入私有配置再整目录压缩。

源码使用仓库LICENSE中的MIT许可；依赖见THIRD-PARTY-NOTICES.md。此源码包不内嵌第三方依赖。后续制作exe或依赖整包时，须按实际纳入组件另核许可与通知；当前源码审查不能代替那一步。

最小发布验收：源码内版本一致；相对文档链接和入口可定位；解压后测试/虚构示例通过；默认配置禁止部署；没有私人路径、账号、学习材料和原始用量日志；已知限制写入README及版本说明。缓存、其他客户端与安装环境证据分别记录，不能互相替代。
