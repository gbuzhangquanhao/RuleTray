# 依赖及许可声明

本项目源码许可见[LICENSE](LICENSE)。当前源码ZIP不包含.runtime、第三方包源码、wheel或已编译程序；下面记录本机实测依赖的元数据，不宣称覆盖其他安装组合。

| 组件 | 本机实测版本 | 包元数据标识 | 来源 |
|---|---|---|---|
| pystray | 0.19.5 | LGPLv3；包附COPYING及COPYING.LGPL | https://github.com/moses-palmer/pystray |
| Pillow | 13.0.0 | MIT-CMU | https://github.com/python-pillow/Pillow |
| six（pystray传递依赖） | 1.17.0 | MIT | https://github.com/benjaminp/six |

运行环境：本机Python3.12，Tk来自本机Python安装。核心与缓存观察器使用标准库；图形菜单使用上述依赖。其他平台可能有pystray平台依赖，本项目未验收相应界面。

pyproject.toml中的范围允许安装兼容版本，不能把本机版本当成所有平台的精确锁定环境。重新发布依赖、制作exe或分发Python/Tk运行时时，应按实际包含的文件保留对应许可/通知并重新核对。不要把本项目MIT标识覆盖到第三方组件上。
