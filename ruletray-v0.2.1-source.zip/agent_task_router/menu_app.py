"""Windows notification-area menu. No floating window or global mouse hooks."""
from __future__ import annotations

from contextlib import nullcontext
import logging
from logging.handlers import RotatingFileHandler
import os
import queue
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

from .core import RouterError, SessionLock
from .manual import OTHER, sha
from .menu_controller import MenuController

LOG = logging.getLogger('agent_task_router.menu')


def configure_logging(path):
    """Local operational evidence only; never record prompts or rule content."""
    path.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(path, maxBytes=500_000, backupCount=1, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(threadName)s %(message)s'))
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)
    logging.getLogger('pystray').addHandler(handler)
    return handler


class MenuApp:
    def __init__(self, settings_path: Path | None = None):
        import pystray
        from PIL import Image, ImageDraw

        self.settings_path = settings_path or Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'agent-task-router' / 'menu.json'
        self.controller = MenuController(self.settings_path)
        self.root = tk.Tk()
        self.root.withdraw()
        self.root.report_callback_exception = self.report_callback_exception
        self.actions = queue.Queue()
        self.running = True
        self.tray_ready = threading.Event()
        self.tray_error = None
        self.last_result = '尚未在本次运行中切换文件；客户端加载状态未知'
        self.stray = pystray
        bitmap = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(bitmap)
        draw.rounded_rectangle((4, 4, 60, 60), radius=14, fill='#202123')
        for y, width in ((18, 30), (30, 22), (42, 28)):
            draw.rounded_rectangle((17, y, 17 + width, y + 4), radius=2, fill='#d7f8e9')
        self.icon = pystray.Icon('agent-task-router', bitmap, '任务规范', self.make_menu())
        self.menu_revision = self.current_menu_revision()
        self.root.after(100, self.drain)
        self.root.after(1000, self.poll_status)

    def callback(self, action, *args):
        def enqueue(icon, item):
            LOG.info('native_click action=%s task=%s', action.__name__, args[1] if action == self.select and len(args)>1 else '')
            self.actions.put((action, args))
        return enqueue

    def report_callback_exception(self, kind, error, traceback):
        LOG.error('tk_callback_failed', exc_info=(kind, error, traceback))
        self.last_result = '界面操作异常：' + str(error)

    def current_menu_revision(self):
        """Refresh choices when config changes even if default file stays equal."""
        selected = self.controller.selected
        try:
            return (selected, sha(Path(selected).read_bytes()) if selected else None, self.controller.enabled)
        except OSError:
            return (selected, None, self.controller.enabled)

    def make_menu(self):
        Menu, Item = self.stray.Menu, self.stray.MenuItem
        c = self.controller
        projects = []
        for path in c.settings['projects']:
            try:
                r = c.router(path)
                label = r.config.get('name', r.root.name)
            except (OSError, ValueError, RouterError):
                label = Path(path).stem + '（配置不可用）'
            projects.append(Item(label, self.callback(self.choose_project, path),
                                 checked=lambda item, p=path: c.selected == p, radio=True))
        projects.extend([Menu.SEPARATOR, Item('添加项目配置…', self.callback(self.add_project))])
        tasks = []
        project_label = '目标项目：未选择'
        try:
            router = c.router()
            project_label = '目标项目：' + router.config.get('name', router.root.name)
            path, target = c.selected, str(router.target)
            config_sha = sha(Path(path).read_bytes())
            tasks.append(Item(str(router.root), None, enabled=False))
            tasks.append(Menu.SEPARATOR)
            current = c.observed.get('route_id') if c.observed['state'] == 'verified' else None
            for r in router.routes:
                rid = r['id']
                tasks.append(Item(r.get('name', rid), self.callback(self.select, path, rid, target, config_sha),
                                  checked=lambda item, t=rid, active=current: active == t, radio=True, enabled=c.enabled))
            tasks.extend([Menu.SEPARATOR, Item('其他任务（完整默认规则）', self.callback(self.select, path, OTHER, target, config_sha),
                                             checked=lambda item, active=current: active == OTHER, radio=True, enabled=c.enabled)])
        except (OSError, ValueError, RouterError):
            tasks.append(Item('请先添加有效项目', None, enabled=False))
        return Menu(Item(project_label, Menu(*projects)), *tasks,
                    Menu.SEPARATOR, Item('文件状态：' + c.observed['message'], None, enabled=False),
                    Item('查看状态与使用说明', self.callback(self.show_status), default=True),
                    Item('停用并恢复所有项目…' if c.enabled else '重试恢复默认规则…', self.callback(self.disable)),
                    Item('启用任务选择', self.callback(self.enable), enabled=not c.enabled),
                    Item('退出（保留当前规则）', self.callback(self.close)))

    def disable(self):
        plan = self.controller.preview_disable()
        detail = '\n'.join(p.get('target', p['config']) + '\n  ' +
                           (p.get('error') or p['status']['message']) for p in plan)
        if not messagebox.askyesno('停用与恢复预览', '将停止任务选择，并恢复以下已登记项目的完整默认规则。\n'
                                  '外部修改或损坏会保留原状并报告；不会刷新已有对话。\n\n' + detail, parent=self.root):
            return
        results = self.controller.disable(plan)
        failures = [r for r in results if r.get('error')]
        self.last_result = f'已停用；{len(results)-len(failures)}/{len(results)} 个项目恢复完成。'
        if failures:
            messagebox.showwarning('部分项目尚未恢复', self.last_result + '\n\n' +
                                   '\n'.join(r['config'] + ': ' + r['error'] for r in failures), parent=self.root)
        else:
            messagebox.showinfo('任务规范', self.last_result, parent=self.root)

    def enable(self):
        self.controller.enable()
        self.last_result = '已启用任务选择；尚未写入规则。'

    def update_menu(self):
        self.icon.menu = self.make_menu()
        try:
            self.icon.title = self.controller.status()[:120]
        except (OSError, ValueError, RouterError):
            self.icon.title = '任务规范 · 配置不可用'
        self.icon.update_menu()
        self.menu_revision = self.current_menu_revision()

    def poll_status(self):
        if not self.running:
            return
        try:
            before = self.controller.observed
            self.controller.refresh_status()
            if before != self.controller.observed or self.current_menu_revision() != self.menu_revision:
                self.update_menu()
        except Exception:
            LOG.exception('status_poll_failed; retrying next tick')
        finally:
            if self.running:
                self.root.after(1000, self.poll_status)

    def drain(self):
        try:
            while not self.actions.empty() and self.running:
                action, args = self.actions.get_nowait()
                LOG.info('action_start action=%s', action.__name__)
                try:
                    action(*args)
                    LOG.info('action_done action=%s state=%s', action.__name__, self.controller.observed.get('route_id'))
                except Exception as exc:
                    self.last_result = str(exc)
                    LOG.exception('action_failed action=%s', action.__name__)
                    messagebox.showerror('任务规范', self.last_result, parent=self.root)
                finally:
                    if self.running:
                        self.controller.refresh_status()
                        self.update_menu()
        except Exception:
            LOG.exception('event_drain_failed; queue remains available')
        finally:
            if self.running:
                self.root.after(100, self.drain)

    def choose_project(self, path):
        self.controller.choose_project(path)
        self.last_result = '已切换浏览项目，未写入规则；右键重新打开菜单后选择任务。原客户端项目未改变。'

    def select(self, path, task, target, config_sha=None):
        result = self.controller.select(path, task, expected_target=target, expected_config=config_sha)
        self.last_result = ('文件内容未变' if result['status'] == 'unchanged' else '规则文件已切换') + '；请在原客户端新开对话。客户端加载未验证。'
        self.icon.title = self.controller.status()[:120]
        if result['status'] != 'unchanged' and self.icon.HAS_NOTIFICATION:
            try:
                self.icon.notify(self.last_result, self.controller.status())
            except OSError:
                self.last_result += '（系统通知不可用；文件状态已核验）'

    def add_project(self):
        path = filedialog.askopenfilename(parent=self.root, title='选择项目 Agent 提供的配置', filetypes=[('JSON', '*.json')])
        if path:
            self.choose_project(path)

    def show_status(self):
        self.controller.refresh_status()
        try:
            status = self.controller.status()
        except (OSError, ValueError, RouterError) as exc:
            status = str(exc)
        messagebox.showinfo('任务规范', status + '\n\n' + self.last_result +
                            '\n\n选项目仅浏览；重新打开菜单，点具体任务才写入规则。'
                            '\n请核对原客户端也打开了同一项目；菜单不会替它切换项目。'
                            '\n选择“其他任务”恢复完整默认规则。退出仅关闭菜单。'
                            '\n全局停用会先预览，再恢复所有已登记项目；冲突保留并可重试。'
                            '\n图标可位于任务栏或小三角内；位置由 Windows 设置管理。'
                            '\n已有对话可能继续使用旧规则；同一项目只支持一个当前档位。', parent=self.root)

    def close(self):
        self.running = False
        self.icon.stop()
        self.destroy_root()

    def destroy_root(self):
        # Cancel callbacks before Tcl teardown, including failed/duplicate startup.
        for timer in self.root.tk.call('after', 'info'):
            self.root.after_cancel(timer)
        self.root.destroy()

    def run(self, lock_held=False):
        if os.name != 'nt':
            raise RouterError('当前图形外壳仅验证 Windows；其他平台可复用独立核心')
        def setup(icon):
            try:
                icon.visible = True
                self.tray_ready.set()
            except Exception as exc:
                self.tray_error = exc
        def worker():
            try:
                self.icon.run(setup)
            except Exception as exc:
                self.tray_error = exc
        started = time.monotonic()
        def check_start():
            if not self.running:
                return
            if self.tray_error is not None:
                self.close()
            elif not self.tray_ready.is_set():
                if time.monotonic() - started > 10:
                    self.tray_error = RouterError('托盘初始化超时，未启用菜单')
                    self.close()
                else:
                    self.root.after(100, check_start)
        try:
            with nullcontext() if lock_held else SessionLock(self.settings_path.with_suffix('.lock')):
                # Windows supports run() outside the main thread. A daemon
                # worker also prevents a failed native startup hanging Python.
                thread = threading.Thread(target=worker, daemon=True)
                thread.start()
                self.root.after(100, check_start)
                self.root.mainloop()
                thread.join(timeout=2)
                if self.tray_error is not None:
                    raise RouterError(f'托盘启动失败：{self.tray_error}')
        finally:
            self.icon.stop()
            if self.running:
                self.destroy_root()


def main():
    path = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'agent-task-router' / 'menu.json'
    lock = SessionLock(path.with_suffix('.lock'))
    try:
        lock.__enter__()
    except RouterError:
        messagebox.showinfo('任务规范', '菜单已在运行。请在任务栏或小三角内找到“任务规范”图标，右键选择任务。')
        return
    try:
        handler = configure_logging(path.with_name('menu.log'))
        LOG.info('startup pid=%s build=menu-recovery-1', os.getpid())
        MenuApp(path).run(lock_held=True)
    finally:
        lock.__exit__(None, None, None)


if __name__ == '__main__':
    main()
