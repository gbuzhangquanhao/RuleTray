from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


MARKER_DEFAULT = "<!-- ===== TASK ROUTER GENERATED SECTION ===== -->"


class RouterError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        last_error: OSError | None = None
        for attempt in range(5):
            try:
                os.replace(name, path)
                last_error = None
                break
            except PermissionError as exc:
                last_error = exc
                time.sleep(0.05 * (attempt + 1))
        if last_error is not None:
            raise last_error
    finally:
        if os.path.exists(name):
            os.unlink(name)


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise RouterError(f"配置不存在：{path}") from exc
    except json.JSONDecodeError as exc:
        raise RouterError(f"配置不是合法 JSON：{path}: {exc}") from exc


def write_json(path: Path, value: Any) -> None:
    atomic_write(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def resolve_path(value: str | Path, base: Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (base / path).resolve()


def config_context(config_path: Path) -> tuple[dict[str, Any], Path, Path]:
    config_path = config_path.resolve()
    config = load_json(config_path)
    if not isinstance(config, dict) or not isinstance(config.get('root', '.'), str):
        raise RouterError('项目配置必须是 JSON 对象，root 必须是路径字符串')
    config_base = config_path.parent
    root = resolve_path(config.get("root", "."), config_base)
    return config, root, config_base


def _select_markdown_section(content: str, start_heading: str | None, end_heading: str | None) -> str:
    """Select a markdown heading range without making the whole file a route dependency."""
    if not start_heading:
        return content
    lines = content.splitlines(keepends=True)
    matches = [i for i, line in enumerate(lines) if line.strip() == start_heading.strip()]
    start = matches[0] if len(matches) == 1 else None
    if start is None:
        raise RouterError(f"规范中找不到章节标题：{start_heading}")
    end = len(lines)
    if end_heading:
        matches = [i for i in range(start + 1, len(lines)) if lines[i].strip() == end_heading.strip()]
        if len(matches) != 1:
            raise RouterError(f'结束章节缺失或不唯一：{end_heading}')
        end = matches[0]
    return "".join(lines[start:end])


def route_docs(route: dict[str, Any], root: Path, config_base: Path, max_inline_chars: int = 120_000) -> list[tuple[str, str]]:
    docs: list[tuple[str, str]] = []
    for raw in route.get("docs", []):
        if isinstance(raw, dict):
            raw_path = raw.get("path")
            if not raw_path:
                raise RouterError(f"路由规范项缺少 path：{route.get('id')}")
            path = resolve_path(str(raw_path), root if route.get("docs_relative_to_root", True) else config_base)
            start_heading = str(raw.get("start_heading")) if raw.get("start_heading") else None
            end_heading = str(raw.get("end_heading")) if raw.get("end_heading") else None
        else:
            path = resolve_path(raw, root if route.get("docs_relative_to_root", True) else config_base)
            start_heading = end_heading = None
        if not path.is_file():
            raise RouterError(f"路由规范文件不存在：{path}")
        content = path.read_text(encoding="utf-8")
        content = _select_markdown_section(content, start_heading, end_heading)
        if len(content) > max_inline_chars:
            raise RouterError(f"规范文件过长，拒绝无上限内联：{path} ({len(content)} chars)")
        docs.append((str(path), content))
    return docs


def render_tail(route: dict[str, Any], root: Path, config_base: Path, max_inline_chars: int = 120_000) -> bytes:
    route_id = route["id"]
    chunks = [
        "",
        "## Active task route",
        "",
        f"- route_id: `{route_id}`",
        "- generated_by: `agent-task-router`",
        "",
    ]
    total_chars = 0
    for path, content in route_docs(route, root, config_base, max_inline_chars):
        total_chars += len(content)
        if total_chars > max_inline_chars:
            raise RouterError(f"路由规范总长度超过上限：{route['id']} ({total_chars} chars)")
        chunks.extend([f"### Route document: `{path}`", "", content.rstrip("\r\n"), ""])
    return ("\n".join(chunks)).encode("utf-8")


def split_at_marker(data: bytes, marker: str) -> tuple[bytes, bytes]:
    marker_bytes = marker.encode("utf-8")
    offset = 0
    for line in data.splitlines(keepends=True):
        content = line.rstrip(b"\r\n")
        if content == marker_bytes:
            return data[:offset + len(line)], data[offset + len(line):]
        offset += len(line)
    raise RouterError(f"AGENTS 文件缺少独立标记行，拒绝替换：{marker}")


def generated_bytes(original: bytes, marker: str, tail: bytes) -> bytes:
    prefix, _ = split_at_marker(original, marker)
    return prefix + tail


def process_alive(pid: int | None) -> bool:
    if not pid or pid <= 0:
        return False
    if os.name == 'nt':
        # os.kill(pid, 0) can terminate processes on Windows. Query, never signal.
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return ctypes.get_last_error() != 87  # Only invalid PID proves absence.
        try:
            code = wintypes.DWORD()
            return not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except PermissionError:
        # On Windows, access denied is evidence of a live process, not proof of death.
        return True
    except (OSError, ProcessLookupError):
        return False
    return True


class SessionLock:
    def __init__(self, path: Path):
        self.path = path

    def __enter__(self) -> "SessionLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Kernel-owned locks are released on process exit; never unlink a lock
        # another process may have opened, or reclaim it based on a stale PID.
        self.handle = self.path.open('a+b')
        try:
            self.handle.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.handle.close()
            raise RouterError(f'已有实例占用锁：{self.path}') from exc
        return self

    def __exit__(self, *_: Any) -> None:
        try:
            if os.name == 'nt':
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle, fcntl.LOCK_UN)
        finally:
            self.handle.close()


@dataclass
class Decision:
    label: str | None
    score: float
    margin: float
    reason: str

    @property
    def accepted(self) -> bool:
        return self.label is not None


_TOKEN_RE = re.compile(r"\w+", re.UNICODE)


def rule_decision(text: str, routes: Iterable[dict[str, Any]], min_score: float, min_margin: float) -> Decision:
    """Conservative fallback classifier used before a trained model exists.

    Route definitions are supplied by the consuming project. This function never
    invents categories and abstains when the top score is weak or ambiguous.
    """
    lowered = text.casefold()
    scored: list[tuple[float, str]] = []
    for route in routes:
        score = 0.0
        for phrase in route.get("phrases", []):
            if str(phrase).casefold() in lowered:
                score += float(route.get("phrase_weight", 3.0))
        for keyword in route.get("keywords", []):
            if str(keyword).casefold() in lowered:
                score += float(route.get("keyword_weight", 1.0))
        for pattern in route.get("patterns", []):
            if re.search(str(pattern), text, flags=re.IGNORECASE):
                score += float(route.get("pattern_weight", 2.0))
        for pattern in route.get("negative_patterns", []):
            if re.search(str(pattern), text, flags=re.IGNORECASE):
                score -= float(route.get("negative_weight", 2.0))
        scored.append((score, str(route["id"])))
    scored.sort(reverse=True)
    if not scored or scored[0][0] < min_score:
        return Decision(None, scored[0][0] if scored else 0.0, 0.0, "top score below threshold")
    second = scored[1][0] if len(scored) > 1 else 0.0
    margin = scored[0][0] - second
    if margin < min_margin:
        return Decision(None, scored[0][0], margin, "top two routes are too close")
    return Decision(scored[0][1], scored[0][0], margin, "rule threshold accepted")


def runtime_paths(agents_file: Path) -> tuple[Path, Path, Path]:
    identity = hashlib.sha256(str(agents_file.resolve()).encode("utf-8")).hexdigest()[:20]
    base = Path(tempfile.gettempdir()) / "agent-task-router" / identity
    return base / "state.json", base / "lock", base


class SafeAgentsSession:
    """Transactional replacement and recovery for one AGENTS-like file."""

    def __init__(self, agents_file: Path, marker: str, runtime_dir: Path | None = None):
        self.agents_file = agents_file.resolve()
        self.marker = marker
        default_state, default_lock, default_runtime = runtime_paths(self.agents_file)
        self.runtime_dir = runtime_dir.resolve() if runtime_dir else default_runtime
        self.state_path = self.runtime_dir / "state.json"
        self.lock_path = self.runtime_dir / "lock"
        self.lock = SessionLock(self.lock_path)
        self.state: dict[str, Any] | None = None

    def recover_stale(self) -> str:
        if not self.state_path.exists():
            return "no stale state"
        state = load_json(self.state_path)
        if not self.agents_file.exists():
            raise RouterError(f"状态存在但 AGENTS 文件不存在：{self.agents_file}")
        current = self.agents_file.read_bytes()
        current_hash = sha256_bytes(current)
        if current_hash == state.get("original_sha256"):
            self._cleanup_state(state)
            return "stale state already restored"
        if current_hash != state.get("generated_sha256"):
            raise RouterError("AGENTS 文件既不是原文也不是启动器生成态，拒绝覆盖；请人工核对后清理状态")
        if process_alive(state.get("wrapper_pid")) or process_alive(state.get("child_pid")):
            raise RouterError("上一个启动器或 Agent 进程仍在运行，拒绝并发启动")
        backup = Path(state.get("backup_file", ""))
        if not backup.is_file():
            raise RouterError(f"生成态需要还原，但备份不存在：{backup}")
        atomic_write(self.agents_file, backup.read_bytes())
        self._cleanup_state(state)
        return "stale generated state restored"

    def _cleanup_state(self, state: dict[str, Any]) -> None:
        backup = Path(state.get("backup_file", ""))
        try:
            backup.unlink()
        except FileNotFoundError:
            pass
        try:
            self.state_path.unlink()
        except FileNotFoundError:
            pass

    def start(self, route: dict[str, Any], root: Path, config_base: Path, max_inline_chars: int = 120_000) -> None:
        if not self.agents_file.is_file():
            raise RouterError(f"AGENTS 文件不存在：{self.agents_file}")
        original = self.agents_file.read_bytes()
        # Validate marker before creating any state.
        split_at_marker(original, self.marker)
        backup = self.runtime_dir / f"backup-{time.strftime('%Y%m%d-%H%M%S')}-{os.getpid()}.bin"
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(original)
        try:
            generated = generated_bytes(original, self.marker, render_tail(route, root, config_base, max_inline_chars))
        except Exception:
            try:
                backup.unlink()
            except FileNotFoundError:
                pass
            raise
        state = {
            "agents_file": str(self.agents_file),
            "backup_file": str(backup),
            "original_sha256": sha256_bytes(original),
            "generated_sha256": sha256_bytes(generated),
            "wrapper_pid": os.getpid(),
            "child_pid": None,
            "route_id": route["id"],
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        write_json(self.state_path, state)
        atomic_write(self.agents_file, generated)
        self.state = state

    def set_child_pid(self, pid: int) -> None:
        if not self.state:
            raise RouterError("会话尚未启动")
        self.state["child_pid"] = pid
        write_json(self.state_path, self.state)

    def restore(self) -> None:
        state = self.state or (load_json(self.state_path) if self.state_path.exists() else None)
        if not state:
            return
        current = self.agents_file.read_bytes()
        current_hash = sha256_bytes(current)
        if current_hash != state.get("generated_sha256"):
            raise RouterError("Agent 运行期间 AGENTS 文件发生了外部修改，拒绝覆盖还原")
        backup = Path(state["backup_file"])
        if not backup.is_file():
            raise RouterError(f"还原备份不存在：{backup}")
        atomic_write(self.agents_file, backup.read_bytes())
        self._cleanup_state(state)

