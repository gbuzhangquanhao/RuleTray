"""Project browsing and explicit task publishing, independent of the UI."""
from copy import deepcopy
from pathlib import Path

from .core import RouterError, load_json, write_json
from .manual import ManualRouter, OTHER, sha


class MenuController:
    def __init__(self, settings_path, router_factory=ManualRouter):
        self.path = Path(settings_path)
        self.router_factory = router_factory
        self.settings = load_json(self.path) if self.path.exists() else {"projects": [], "selected": None, "tasks": {}}
        if (not isinstance(self.settings, dict)
                or not isinstance(self.settings.get("projects"), list)
                or not all(isinstance(p, str) for p in self.settings["projects"])
                or not isinstance(self.settings.get("tasks", {}), dict)
                or self.settings.get("selected") is not None and not isinstance(self.settings["selected"], str)):
            raise RouterError("菜单设置格式不正确；保留原文件，请由适配 Agent 修复")
        self.observed = {"state": "unknown", "route_id": None, "message": "尚未核验"}
        self.refresh_status()

    @property
    def selected(self):
        return self.settings.get("selected")

    @property
    def enabled(self):
        return self.settings.get('enabled', True) is True

    def enable(self):
        updated = deepcopy(self.settings)
        updated['enabled'] = True
        write_json(self.path, updated)
        self.settings = updated

    def preview_disable(self):
        """Read-only plan; includes broken registrations rather than hiding them."""
        plan = []
        for path in self.settings['projects']:
            entry = {'config': path}
            try:
                router = self.router(path)
                entry.update(target=str(router.target), config_sha256=sha(Path(path).read_bytes()),
                             current_sha256=sha(router.target.read_bytes()), status=router.inspect())
            except (OSError, ValueError, RouterError, KeyError, TypeError) as exc:
                entry['error'] = str(exc)
            plan.append(entry)
        return plan

    def disable(self, plan):
        if [p['config'] for p in plan] != self.settings['projects']:
            raise RouterError('项目清单已变化，请重新预览停用影响')
        # Persist intent first. Even a partial recovery failure must block new task writes.
        updated = deepcopy(self.settings)
        updated.update(enabled=False, pending_restore=plan)
        write_json(self.path, updated)
        self.settings = updated
        results = []
        for entry in plan:
            result = {'config': entry['config']}
            try:
                if entry.get('error'):
                    raise RouterError(entry['error'])
                if sha(Path(entry['config']).read_bytes()) != entry['config_sha256']:
                    raise RouterError('预览后配置已变化')
                router = self.router(entry['config'])
                if str(router.target) != entry['target']:
                    raise RouterError('预览后恢复目标已变化')
                result.update(router.restore(check_deployment=True, expected_current=entry['current_sha256']))
            except (OSError, ValueError, RouterError, KeyError, TypeError) as exc:
                result['error'] = str(exc)
            results.append(result)
        updated = deepcopy(self.settings)
        updated['pending_restore'] = [p for p, r in zip(plan, results) if r.get('error')]
        updated['last_restore'] = results
        write_json(self.path, updated)
        self.settings = updated
        self.refresh_status()
        return results

    def router(self, path=None):
        path = path or self.selected
        if not path:
            raise RouterError("请先添加项目 Agent 准备好的配置")
        return self.router_factory(Path(path))

    def task(self, path=None):
        """Last remembered choice only; never used to check a menu item."""
        return self.settings.get("tasks", {}).get(path or self.selected)

    def choose_project(self, path):
        path = str(Path(path).resolve())
        self.router(path)  # Validate configuration, but do not publish a task.
        updated = deepcopy(self.settings)
        if path not in updated["projects"]:
            updated["projects"].append(path)
        updated["selected"] = path
        write_json(self.path, updated)
        self.settings = updated
        return self.refresh_status()

    def refresh_status(self):
        try:
            self.observed = self.router().inspect()
        except (OSError, ValueError, RouterError, KeyError, TypeError) as exc:
            self.observed = {"state": "unknown", "route_id": None, "message": str(exc)}
        return self.observed

    def select(self, path=None, task=None, expected_target=None, expected_config=None):
        if not self.enabled:
            raise RouterError('功能已停用；请先启用，或重试恢复默认规则')
        if task is None:
            raise RouterError("请选择具体任务；切换项目本身不会写入规则")
        path = str(Path(path or self.selected).resolve()) if path or self.selected else None
        if path != self.selected:
            raise RouterError("菜单对应项目已变化，请重新打开菜单选择任务")
        if expected_config is not None and sha(Path(path).read_bytes()) != expected_config:
            raise RouterError('菜单生成后配置已变化，请重新打开菜单核对')
        router = self.router(path)
        if expected_target is not None and str(router.target) != expected_target:
            raise RouterError("配置目标文件已变化，请重新打开菜单核对")
        try:
            result = router.select(task)
        except (OSError, ValueError, RouterError, KeyError, TypeError) as exc:
            observed = self.refresh_status()
            if observed["state"] == "pending" and observed.get("pending_phase") == "written":
                detail = "磁盘已是所选任务，事务记录待恢复"
            elif observed["state"] == "verified":
                detail = "磁盘当前为：" + self.task_name(observed["route_id"])
            else:
                detail = observed["message"]
            raise RouterError(f"任务操作未完整完成。{detail}。原因：{exc}") from exc
        updated = deepcopy(self.settings)
        updated.setdefault("tasks", {})[path] = task
        self.settings = updated
        self.refresh_status()
        try:
            write_json(self.path, updated)
        except OSError as exc:
            raise RouterError(f"规则文件已处理，但菜单偏好未保存；当前文件状态：{self.observed['message']}。{exc}") from exc
        if self.observed["state"] != "verified" or self.observed["route_id"] != task:
            raise RouterError("操作后文件状态未确认；" + self.observed["message"])
        return result

    def task_name(self, task):
        if task == OTHER:
            return "其他任务（完整默认规则）"
        return next((r.get("name", r["id"]) for r in self.router().routes if r["id"] == task), "未知任务")

    def status(self):
        if not self.selected:
            return "尚未选择项目"
        router = self.router()
        text = f"目标项目：{router.config.get('name', router.root.name)}"
        if self.observed.get("route_id"):
            text += " · " + self.task_name(self.observed["route_id"])
        return ('已停用 · ' if not self.enabled else '') + text + " · " + self.observed["message"]
