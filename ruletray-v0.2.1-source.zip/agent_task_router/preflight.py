"""Read-only adaptation evidence; warnings require human/Agent semantic review."""
from pathlib import Path
import re

from .core import resolve_path, RouterError
from .manual import ManualRouter, sha


def inspect_config(config_path, reference_patterns=None):
    router = ManualRouter(Path(config_path))
    patterns = reference_patterns or [r'[^\s`\[\]（）()]+\.md']
    report = {'config_sha256': sha(Path(config_path).read_bytes()),
              'format': router.config.get('format', 2),
              'deployment_ready': router.config.get('deployment_ready') is True,
              'default_is_complete': router.config.get('default_is_complete') is True,
              'target_status': router.inspect(), 'routes': []}
    for route in router.routes:
        source = resolve_path(route['docs'][0], router.root if route.get('docs_relative_to_root', True) else router.base)
        raw = source.read_bytes()
        warnings = [{'line': i, 'text': line, 'reason': '文件引用候选，需审查是否要求转读另一份规范'}
                    for i, line in enumerate(raw.decode('utf-8-sig').splitlines(), 1)
                    if any(re.search(pattern, line, re.I) for pattern in patterns)]
        item = {'id': route['id'], 'source': route['docs'][0], 'source_sha256': sha(raw),
                'approved_sha256': route.get('spec_sha256'), 'version': route.get('spec_version'),
                'warnings': warnings}
        try:
            generated = router.render(route['id'])
            item.update(rendered_sha256=sha(generated), rendered_bytes=len(generated))
        except (OSError, ValueError, RouterError) as exc:
            item['error'] = str(exc)
        report['routes'].append(item)
    return report


def main():
    """Optional read-only Agent diagnostic; users use the tray."""
    import argparse
    import json
    parser = argparse.ArgumentParser(description='Read-only single-spec configuration audit')
    parser.add_argument('config', type=Path)
    args = parser.parse_args()
    print(json.dumps(inspect_config(args.config), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
