"""Manual task selection and persistent, reversible instruction-file publishing.

No model, UI automation, client process, network or session assumptions.
"""
from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path

from .core import RouterError, SessionLock, atomic_write, config_context, load_json, write_json, resolve_path

MARKER = '<!-- TASK-ROUTER:MANAGED -->'
OTHER = '__other__'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class ManualRouter:
    def __init__(self, config_path: Path, runtime: Path | None = None):
        self.config_path = config_path.resolve()
        self.config, self.root, self.base = config_context(self.config_path)
        if self.config.get('mode') != 'manual_file':
            raise RouterError('需要 mode=manual_file 的项目配置；旧分类配置不再是主入口')
        raw = self.config.get('target_file')
        if not isinstance(raw, str) or not raw:
            raise RouterError('项目 Agent 必须确认 target_file，不能猜测规则入口')
        self.target = (self.root / raw).resolve()
        self.marker = self.config.get('marker', MARKER)
        if not isinstance(self.marker, str) or not self.marker.strip() or '\n' in self.marker or '\r' in self.marker:
            raise RouterError('受管标记必须是非空单行文本')
        self.routes = self.config.get('routes', [])
        if not isinstance(self.routes, list) or not all(isinstance(r, dict) for r in self.routes):
            raise RouterError('routes 必须是任务对象数组')
        ids = [r.get('id') for r in self.routes]
        if not ids or not all(isinstance(i, str) and i and '\n' not in i and '\r' not in i for i in ids) or len(set(ids)) != len(ids) or OTHER in ids:
            raise RouterError('任务 id 必须非空且唯一')
        for route in self.routes:
            docs = route.get('docs')
            if not isinstance(docs, list) or len(docs) != 1 or not isinstance(docs[0], str) or not docs[0].strip():
                raise RouterError('一任务必须对应一个完整规范文件；请审阅合并旧多文件/章节配置后再迁移')
        identity = sha(str(self.target).casefold().encode())[:24]
        self.runtime = runtime or Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.local' / 'state'))) / 'agent-task-router' / identity
        self.state_path = self.runtime / 'state.json'
        self.lock = SessionLock(self.runtime / 'lock')

    def render(self, route_id: str) -> bytes:
        route = next((r for r in self.routes if r['id'] == route_id), None)
        if route is None:
            raise RouterError('任务不存在')
        limit = int(self.config.get('max_inline_chars', 120000))
        chunks = [f'## Active task: {route_id}', '']
        path = resolve_path(route['docs'][0], self.root if route.get('docs_relative_to_root', True) else self.base).resolve()
        if path == self.target:
            raise RouterError('任务包不能引用其输出规则文件，避免递归增长')
        raw = path.read_bytes()
        pin = route.get('spec_sha256')
        if (self.config.get('format', 2) >= 3 and not pin) or (pin and pin != sha(raw)):
            raise RouterError('规范正文与批准指纹不符或缺少指纹；先审阅新版本，不能直接切换')
        text = raw.decode('utf-8-sig').replace('\r\n', '\n').replace('\r', '\n').strip()
        if not text or self.marker in text.splitlines():
            raise RouterError('规范正文为空或包含受管标记，拒绝生成不可继续切换的规则')
        try:
            title = path.relative_to(self.root).as_posix()
        except ValueError:
            title = path.name
        chunks.extend([f'### Source: {title}', '', text, ''])
        result = '\n'.join(chunks).rstrip() + '\n'
        if len(result) > limit:
            raise RouterError('整个规范包超出长度上限')
        return result.encode('utf-8')

    def _prefix(self, data: bytes) -> bytes:
        lines = data.splitlines(keepends=True)
        matches = [i for i, line in enumerate(lines) if line.rstrip(b'\r\n') == self.marker.encode()]
        if len(matches) != 1:
            raise RouterError('规则文件需要恰好一个受管标记；先审阅拆分草案，工具不会自动插入')
        line = lines[matches[0]]
        if not line.endswith(b'\n'):
            raise RouterError('受管标记行需要换行结尾')
        return b''.join(lines[:matches[0] + 1])

    def _state(self, current: bytes):
        if not self.state_path.exists():
            return None
        state = load_json(self.state_path)
        if not isinstance(state, dict):
            raise RouterError('事务状态格式损坏，拒绝继续写入')
        if state.get('target') != str(self.target):
            raise RouterError('状态文件的目标路径不一致')
        try:
            original = base64.b64decode(state['original_b64'], validate=True)
            if sha(original) != state['original_sha']:
                raise ValueError('hash mismatch')
        except (KeyError, ValueError, TypeError) as exc:
            raise RouterError('恢复备份损坏，拒绝继续写入') from exc
        if state.get('pending'):
            pending = state['pending']
            if sha(current) == pending['next']:
                state.update(current_sha=pending['next'], active=pending['active'], route_id=pending.get('route_id'))
            elif sha(current) != state['current_sha']:
                raise RouterError('中断期间目标已被外部修改；保留备份并拒绝覆盖')
            state.pop('pending')
            write_json(self.state_path, state)
        if sha(current) != state['current_sha']:
            raise RouterError('规则文件有外部修改；请先人工合并，不自动覆盖或还原')
        return state

    def inspect(self):
        """Read the file and journal without repairing or publishing anything.

        A preference is never proof of the currently installed task. Pending
        transactions describe both possible disk outcomes until next selection.
        """
        result = {'state': 'unknown', 'route_id': None, 'target': str(self.target),
                  'message': '规则文件状态待核验'}
        try:
            with self.lock:
                current = self.target.read_bytes()
                result['sha256'] = sha(current)
                state = load_json(self.state_path) if self.state_path.exists() else None
                self._check_deployment(current, state)
                self._prefix(current)
                if state is None:
                    route_id = OTHER
                    pending = None
                else:
                    if state.get('target') != str(self.target):
                        raise RouterError('状态目标路径不一致')
                    original = base64.b64decode(state['original_b64'], validate=True)
                    if sha(original) != state['original_sha']:
                        raise RouterError('恢复备份校验失败')
                    pending = state.get('pending')
                    if pending and sha(current) == pending['next']:
                        active, route_id = pending['active'], pending.get('route_id')
                        result['pending_phase'] = 'written'
                    elif sha(current) == state['current_sha']:
                        active, route_id = state['active'], state.get('route_id')
                        if pending:
                            result['pending_phase'] = 'not_written'
                    else:
                        result.update(state='conflict', message='规则文件被外部修改；暂停切换，先人工合并')
                        return result
                    if not active:
                        route_id = OTHER
                result['route_id'] = route_id
                if pending:
                    message = '文件已写入，事务记录待恢复' if result['pending_phase'] == 'written' else '上次操作未写入，事务记录待恢复'
                    result.update(state='pending', message=message + '；请重新选择任务')
                elif route_id == OTHER:
                    if sha(current) != self.config['baseline_sha256']:
                        raise RouterError('默认规则与完整基线不一致')
                    result.update(state='verified', message='文件已核验：完整默认规则')
                elif self._prefix(current) + self.render(route_id) != current:
                    result.update(state='stale', message='任务规范源已变化；请重新选择任务以更新文件')
                else:
                    result.update(state='verified', message='规则文件与当前任务包一致')
        except (OSError, RouterError, ValueError, KeyError, TypeError) as exc:
            result.update(state='unknown', message='状态待核验：' + str(exc))
        return result

    def preview(self, route_id: str):
        current = self.target.read_bytes()
        generated = self._prefix(current) + self.render(route_id)
        return {'target': str(self.target), 'before_sha256': sha(current),
                'after_sha256': sha(generated), 'bytes': len(generated),
                'changed': current != generated, 'text': generated.decode('utf-8')}

    def apply(self, route_id: str, expected: dict | None = None):
        with self.lock:
            current = self.target.read_bytes()
            state = self._state(current)
            self._check_deployment(current, state)
            generated = self._prefix(current) + self.render(route_id)
            if expected and (expected['before_sha256'] != sha(current) or expected['after_sha256'] != sha(generated)):
                raise RouterError('预览后源文件或目标已变化，请重新预览')
            if generated == current:
                return {'status': 'unchanged', 'sha256': sha(current)}
            if state is None:
                state = {'target': str(self.target), 'original_b64': base64.b64encode(current).decode(),
                         'original_sha': sha(current), 'current_sha': sha(current), 'active': False}
            return self._commit(state, generated, True, route_id)

    def _commit(self, state, data, active, route_id=None):
        if sha(self.target.read_bytes()) != state['current_sha']:
            raise RouterError('写入前目标已变化，请重新检查')
        state['pending'] = {'next': sha(data), 'active': active, 'route_id': route_id}
        write_json(self.state_path, state)  # durable backup/journal before modifying target
        atomic_write(self.target, data)
        state.update(current_sha=sha(data), active=active, route_id=route_id)
        state.pop('pending')
        write_json(self.state_path, state)
        return {'status': 'updated' if active else 'restored', 'sha256': sha(data)}

    def _check_deployment(self, current, state):
        if self.config.get('deployment_ready') is not True or self.config.get('default_is_complete') is not True:
            raise RouterError('尚未完成规则拆分审阅与完整默认规则核验；只能预览，不会写入')
        baseline = self.config.get('baseline_sha256')
        actual = state['original_sha'] if state else sha(current)
        if not baseline or baseline != actual:
            raise RouterError('完整默认规则的基线哈希不匹配；请由项目 Agent 核对部署与备份')

    def select(self, route_id: str):
        if route_id != OTHER:
            return self.apply(route_id)
        return self.restore(check_deployment=True)

    def restore(self, check_deployment=False, expected_current=None):
        with self.lock:
            current = self.target.read_bytes()
            if expected_current is not None and sha(current) != expected_current:
                raise RouterError('恢复预览后目标已变化，请重新核对')
            state = self._state(current)
            if check_deployment:
                self._check_deployment(current, state)
                self._prefix(current)
            if state is None or not state.get('active'):
                return {'status': 'unchanged'}
            original = base64.b64decode(state['original_b64'])
            if sha(original) != state['original_sha']:
                raise RouterError('备份校验失败')
            return self._commit(state, original, False)
