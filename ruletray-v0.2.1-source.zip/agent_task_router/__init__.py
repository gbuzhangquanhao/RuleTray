"""Small, dependency-free runtime for task-specific AGENTS injection."""

__version__ = "0.2.1"
