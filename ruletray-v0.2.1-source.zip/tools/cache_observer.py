"""Read-only Codex usage observer. Standard library; never sends model requests.

Only token_usage_record.payload.usage is counted. No conversation text is saved.
Rebuild from logs on each sample: resumable, deduplicated, no private DB edits.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone, timedelta
import hashlib
import html
import json
import os
from pathlib import Path
import re
import statistics
import time
import webbrowser


def stamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def path_key(value):
    return str(value).removeprefix('\\\\?\\').replace('\\', '/').rstrip('/').casefold()


def atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(content, encoding='utf-8')
    os.replace(temp, path)


def dump(path, value):
    atomic(path, json.dumps(value, ensure_ascii=False, indent=2))


def instruction_event(payload, project):
    if payload.get('role') != 'user':
        return None
    for item in payload.get('content', []):
        text = item.get('text', '')
        match = re.match(r'^# AGENTS\.md instructions for ([^\r\n]+)\s+<INSTRUCTIONS>\s*([\s\S]*?)</INSTRUCTIONS>', text)
        if not match or path_key(match[1]) != path_key(project):
            continue
        body = match[2].replace('\r\n', '\n').replace('\r', '\n')
        route = None
        if '<!-- TASK-ROUTER:MANAGED -->' in body:
            active = re.search(r'^## Active task: ([^\n]+)$', body, re.M)
            if active:
                route = active[1].strip()
            elif '当前任务：其他任务' in body:
                route = '__other__'
        return {'rule_hash': hashlib.sha256(body.encode()).hexdigest(), 'injected_task': route}
    return None


def read_logs(paths, project, since, until, labels=None):
    """Return sanitized responses. Missing cache counters are unknown, never zero."""
    labels = labels or {}
    responses, events, contexts = {}, defaultdict(list), {}
    diagnostics = defaultdict(int)
    threads = set()
    for path in sorted(paths):
        meta = None
        try:
            with Path(path).open('rb') as handle:
                for raw in handle:
                    if not raw.endswith(b'\n'):
                        diagnostics['partial_lines'] += 1
                        break
                    try:
                        row = json.loads(raw)
                    except (ValueError, UnicodeError):
                        diagnostics['invalid_lines'] += 1
                        continue
                    kind, p = row.get('type'), row.get('payload', {})
                    if kind == 'session_meta':
                        meta = p
                        if path_key(p.get('cwd', '')) != path_key(project):
                            diagnostics['excluded_project_files'] += 1
                            break
                        if not isinstance(p.get('source'), str) or p.get('thread_source') == 'subagent':
                            diagnostics['excluded_agent_files'] += 1
                            break
                        threads.add(p['id'])
                        diagnostics['included_files'] += 1
                        continue
                    if not meta:
                        continue
                    tid, ts = meta['id'], row.get('timestamp', '')
                    if kind == 'turn_context':
                        contexts[(tid, p.get('turn_id'))] = p.get('model', 'unknown')
                    elif kind == 'response_item':
                        info = instruction_event(p, project)
                        if info and ts:
                            events[tid].append((ts, info))
                    elif kind == 'token_usage_record' and p.get('thread_id') == tid:
                        rid = p.get('response_id')
                        if not rid or not ts:
                            diagnostics['missing_identity'] += 1
                            continue
                        u = p.get('usage', {})
                        inp, cached = u.get('input_tokens'), u.get('cached_input_tokens')
                        if type(inp) is not int or type(cached) is not int or not 0 <= cached <= inp:
                            diagnostics['missing_or_invalid_usage'] += 1
                            continue
                        record = {'response_id': rid, 'thread_id': tid, 'timestamp': ts,
                                  'turn_id': p.get('turn_id'), 'root_turn_id': p.get('root_turn_id') or p.get('turn_id'),
                                  'input_tokens': inp, 'cached_input_tokens': cached,
                                  'cache_write_input_tokens': u.get('cache_write_input_tokens'),
                                  'output_tokens': u.get('output_tokens')}
                        if rid in responses:
                            diagnostics['duplicate_records'] += 1
                            if responses[rid] != record:
                                diagnostics['conflicting_duplicates'] += 1
                        else:
                            responses[rid] = record
        except OSError:
            diagnostics['unreadable_files'] += 1
    by_thread = defaultdict(list)
    for record in responses.values():
        by_thread[record['thread_id']].append(record)
    result = []
    for tid, records in by_thread.items():
        records.sort(key=lambda r: (r['timestamp'], r['response_id']))
        ev = sorted(events[tid], key=lambda item: item[0])
        index, active = 0, {}
        turns = {r['root_turn_id'] for r in records}
        annotation = labels.get(tid, {})
        for number, record in enumerate(records):
            while index < len(ev) and ev[index][0] <= record['timestamp']:
                active = ev[index][1]
                index += 1
            record['model'] = contexts.get((tid, record['turn_id']), 'unknown')
            record['rule_hash'] = active.get('rule_hash', 'unknown')
            record['task'] = active.get('injected_task') or annotation.get('task', 'unclassified')
            record['task_evidence'] = 'injected' if active.get('injected_task') else ('manual_history' if annotation.get('task') else 'unknown')
            record['title'] = annotation.get('title', tid)
            record['purpose'] = annotation.get('purpose', 'ordinary')
            record['first_observed_request'] = number == 0
            record['observed_root_turns'] = len(turns)
            moment = stamp(record['timestamp'])
            if since <= moment <= until:
                result.append(record)
    diagnostics['threads_with_structured_usage'] = len(by_thread)
    diagnostics['threads_without_structured_usage'] = len(threads - set(by_thread))
    return sorted(result, key=lambda r: (r['timestamp'], r['response_id'])), dict(diagnostics)


def totals(rows):
    inp = sum(r['input_tokens'] for r in rows)
    cached = sum(r['cached_input_tokens'] for r in rows)
    first = [r for r in rows if r['first_observed_request']]
    finp = sum(r['input_tokens'] for r in first)
    fcache = sum(r['cached_input_tokens'] for r in first)
    return {'requests': len(rows), 'threads': len({r['thread_id'] for r in rows}),
            'input_tokens': inp, 'cached_input_tokens': cached, 'uncached_input_tokens': inp-cached,
            'cache_ratio': cached/inp if inp else None,
            'first_requests': len(first), 'first_cache_ratio': fcache/finp if finp else None,
            'first_uncached_median': statistics.median([r['input_tokens']-r['cached_input_tokens'] for r in first]) if first else None,
            'short_first_samples': sum(r['observed_root_turns'] <= 2 for r in first)}


def pct(value):
    return '无样本' if value is None else f'{value*100:.2f}%'


def report(rows, diagnostics, config, now):
    groups, chats = defaultdict(list), defaultdict(list)
    zone = timezone(timedelta(hours=config.get('utc_offset_hours', 8)))
    start = stamp(config['observation_start'])
    for row in rows:
        day = stamp(row['timestamp']).astimezone(zone).date().isoformat()
        period = '观察期' if stamp(row['timestamp']) >= start else '历史'
        key = (period, day, row['task'], row['task_evidence'], row['model'], row['rule_hash'])
        groups[key].append(row)
        chats[row['thread_id']].append(row)
    grouped = [dict(zip(['period','day','task','evidence','model','rule_hash'], key), **totals(values)) for key, values in sorted(groups.items())]
    sessions = [{'thread_id': tid, 'title': values[0]['title'], 'task': values[0]['task'], **totals(values)} for tid,values in chats.items()]
    treated = [r for r in rows if r['first_observed_request'] and r['task_evidence']=='injected' and r['task']!='__other__' and r.get('purpose')!='validation' and stamp(r['timestamp']) >= start]
    comparisons = []
    for task, model, version in sorted({(r['task'], r['model'], r['rule_hash']) for r in treated}):
        after = [r for r in treated if (r['task'],r['model'],r['rule_hash']) == (task,model,version) and r['observed_root_turns'] <= 2]
        before = [r for r in rows if r['first_observed_request'] and r['task']==task and r['model']==model and r.get('purpose')!='validation' and stamp(r['timestamp']) < start and r['observed_root_turns'] <= 2]
        a, b = totals(after), totals(before)
        delta = (a['cache_ratio']-b['cache_ratio'])*100 if a['cache_ratio'] is not None and b['cache_ratio'] is not None else None
        reduction = 1-a['first_uncached_median']/b['first_uncached_median'] if a['first_uncached_median'] is not None and b['first_uncached_median'] else None
        comparisons.append({'task':task,'model':model,'after_rule_hash':version,'baseline_rule_hashes':sorted({r['rule_hash'] for r in before}),
                            'before_samples':len(before),'after_samples':len(after),'cache_difference_percentage_points':delta,
                            'uncached_median_reduction_fraction':reduction,'interpretation':'observational only; prompt length, time and baseline versions uncontrolled'})
    summary = {'generated_at': now.isoformat(), 'observation_start': config['observation_start'],
               'observation_end': config['observation_end'], 'scope': 'local structured per-response input usage; no billing attribution',
               'totals': totals(rows), 'routed_new_chat_samples': len(treated),
               'routed_short_new_chat_samples': sum(r['observed_root_turns'] <= 2 for r in treated),
               'validation_requests':sum(r.get('purpose')=='validation' for r in rows),
               'causal_lift': None, 'comparisons': comparisons, 'diagnostics': diagnostics, 'groups': grouped, 'chats': sessions}
    names = config.get('task_names', {})
    content = ['# 缓存观察报告', '', f'更新时间：{now.astimezone(zone).isoformat(timespec="seconds")}',
               f'观察窗口：{config["observation_start"]} → {config["observation_end"]}', '',
               f'有任务注入证据的新对话：{len(treated)}；其中当前不超过两次 root_turn：{summary["routed_short_new_chat_samples"]}。',
               '', '缓存率＝缓存输入token总和÷输入token总和；不计输出token，不平均单次百分比。',
               f'专用加载验证请求：{summary["validation_requests"]}，保留在用量明细/总体中，排除出真实学习短任务样本和提升对比。',
               '整体高缓存率常由长对话续问构成。下表的首请求为可读取日志中该对话最早响应，缺失早期日志时不保证是真正首次。',
               '缓存提升的因果值：尚未建立。人工历史任务标签不等于实际托盘选择。未记录任务注入的会话不冒充实验组。',
               '短对话样本为当前观察到≤2个root_turn，尚未宣告结束；后续增长会退出此分组。不能把root_turn数量直接等同用户消息数量。',
               '', '| 对话 | 请求数 | 输入token | 缓存token | 整体缓存率 | 首请求缓存率 |', '|---|---:|---:|---:|---:|---:|']
    for item in sessions:
        content.append(f'| {item["title"].replace("|", "/")} | {item["requests"]} | {item["input_tokens"]} | {item["cached_input_tokens"]} | {pct(item["cache_ratio"])} | {pct(item["first_cache_ratio"])} |')
    content += ['', '## 按任务、日期、模型、规则分组', '', '| 时段/日 | 任务/证据 | 模型 | 规则指纹前12位 | 请求 | 首请求样本 | 整体缓存率 | 首请求缓存率 | 首请求未缓存中位数 |', '|---|---|---|---|---:|---:|---:|---:|---:|']
    for item in grouped:
        label = names.get(item['task'], item['task'])
        content.append(f'| {item["period"]}/{item["day"]} | {label}/{item["evidence"]} | {item["model"]} | {item["rule_hash"][:12]} | {item["requests"]} | {item["first_requests"]} | {pct(item["cache_ratio"])} | {pct(item["first_cache_ratio"])} | {item["first_uncached_median"]} |')
    content += ['', '## 可解释范围', '',
                '日志只给整次请求的命中量，不能拆出AGENTS、图片、历史消息各自贡献。规范指纹是日志中规范文本的归一化SHA-256，不是服务端token前缀指纹。',
                '规范内联也可能增加总输入；缓存率提高不必然减少未缓存token，必须同时看输入量、未缓存输入和任务质量。',
                '工具读取sessions及archived_sessions中配置日期以来创建的日志；不读取登录凭据，不保存正文，不写客户端私有配置/数据库。轮转历史按response_id去重；累积快照不相加。',
                '首请求未知、字段缺失、部分行、模型未知及排除文件见diagnostics。旧日期创建且未轮转的会话不在本次范围；原始日志删除后需依赖已保存快照。',
                '不将缓存占比换算为订阅额度节省。不自动发布GitHub。先积累两天真实学习，按同任务同模型比较首请求与未缓存输入；样本少或质量不同只报告观察差异。',
                '', '诊断：`'+json.dumps(diagnostics, ensure_ascii=False)+'`']
    markdown = '\n'.join(content)+'\n'
    def table(headers, items):
        return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(h))+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(cell))+'</td>' for cell in line)+'</tr>' for line in items)+'</tbody></table></div>'
    chat_table = table(['对话','请求','输入 token','缓存 token','整体','首请求'], [[s['title'],s['requests'],f'{s["input_tokens"]:,}',f'{s["cached_input_tokens"]:,}',pct(s['cache_ratio']),pct(s['first_cache_ratio'])] for s in sessions])
    group_table = table(['日期','任务','证据','模型','规则版本','请求','首请求样本','整体','首请求'], [[g['day'],names.get(g['task'],g['task']),g['evidence'],g['model'],g['rule_hash'][:12],g['requests'],g['first_requests'],pct(g['cache_ratio']),pct(g['first_cache_ratio'])] for g in grouped])
    comp_table = table(['任务','模型','新规则','旧/新首请求样本','缓存差异（百分点）','未缓存输入中位数减少'], [[names.get(c['task'],c['task']),c['model'],c['after_rule_hash'][:12],f'{c["before_samples"]}/{c["after_samples"]}', '无可比样本' if c['cache_difference_percentage_points'] is None else f'{c["cache_difference_percentage_points"]:+.2f}',pct(c['uncached_median_reduction_fraction'])] for c in comparisons])
    html_text = ('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="300">'
                 '<title>任务缓存观察</title><style>body{background:#191a1c;color:#ececec;font:15px/1.65 system-ui;margin:24px auto;max-width:1500px;padding:20px}h1{font-size:30px}pre{white-space:pre-wrap;overflow-wrap:anywhere}aside{background:#303238;padding:16px;border-radius:12px}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;margin:16px 0}td,th{padding:10px;text-align:left;border-bottom:1px solid #404247;white-space:nowrap}th{color:#9cddc9}small{color:#b5b8bd}h2{margin-top:36px}</style>'
                 '<h1>任务缓存观察</h1><aside>本地日志统计 · 不调用 AI · 每 10 分钟采样 · 尚未证明因果提升<br>页面每 5 分钟刷新；采样时间停滞时双击“启动缓存观察”恢复。</aside>'
                 '<p>更新：'+html.escape(now.astimezone(zone).isoformat(timespec='seconds'))+f' · 已观测专用任务新对话：{len(treated)} · 短对话：{summary["routed_short_new_chat_samples"]}</p>'
                 '<h2>同任务、同模型：短对话首请求的观察差异</h2><small>未配对实验，任务长度、时段、旧规范版本可能不同；差异不能直接归因于路由器。无样本时保持空白。</small>'+comp_table+
                 '<h2>相关对话</h2>'+chat_table+'<h2>任务与规则分组</h2>'+group_table+'<details><summary>统计口径与完整报告</summary><pre>'+html.escape(markdown)+'</pre></details></html>')
    return summary, markdown, html_text


def sample(config_path):
    config = json.loads(Path(config_path).read_text(encoding='utf-8-sig'))
    now = datetime.now(timezone.utc)
    until = min(now, stamp(config['observation_end']))
    paths = []
    for root in config['log_roots']:
        for path in Path(root).rglob('rollout-*.jsonl'):
            # Filename date, not mtime; no unrelated old chats or transcript export.
            if path.name[8:18] >= config['scan_created_since']:
                paths.append(path)
    rows, diagnostics = read_logs(paths, config['project_root'], stamp(config['history_start']), until, config.get('thread_labels'))
    summary, markdown, page = report(rows, diagnostics, config, now)
    out = Path(config['output_dir'])
    dump(out/'summary.json', summary)
    dump(out/'responses.json', rows)
    atomic(out/'report.md', markdown)
    atomic(out/'dashboard.html', page)
    # Immutable daily observations permit later review even if original logs vanish.
    snapshot = now.strftime('%Y%m%dT%H%M%SZ')
    dump(out/'snapshots'/f'{snapshot}.json', summary)
    return config, summary


class Lock:
    def __init__(self, path):
        self.path, self.handle = Path(path), None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open('a+b')
        self.handle.seek(0, 2)
        if not self.handle.tell():
            self.handle.write(b'0'); self.handle.flush()
        self.handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.handle.close()
            self.handle = None
            raise
        return self

    def __exit__(self, *args):
        if self.handle:
            self.handle.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', type=Path)
    parser.add_argument('--watch', action='store_true')
    parser.add_argument('--open', action='store_true')
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8-sig'))
    out = Path(config['output_dir'])
    lock = Lock(out/'observer.lock')
    try:
        lock.__enter__()
    except OSError:
        if args.open and (out/'dashboard.html').exists():
            webbrowser.open((out/'dashboard.html').as_uri())
            return
        raise
    try:
        while True:
            try:
                config, summary = sample(args.config)
                dump(out/'status.json', {'pid': os.getpid(), 'updated_at': summary['generated_at'], 'state': 'watching' if args.watch else 'sampled', 'error': None})
                if args.open:
                    webbrowser.open((out/'dashboard.html').as_uri()); args.open = False
            except Exception as exc:
                dump(out/'status.json', {'pid': os.getpid(), 'updated_at': datetime.now(timezone.utc).isoformat(), 'state': 'error', 'error': type(exc).__name__+': '+str(exc)})
                if not args.watch:
                    raise
            if not args.watch or datetime.now(timezone.utc) >= stamp(config['observation_end']):
                break
            if (out/'STOP').exists():
                break
            time.sleep(min(config.get('interval_seconds', 600), max(1, (stamp(config['observation_end'])-datetime.now(timezone.utc)).total_seconds())))
        dump(out/'status.json', {'pid': os.getpid(), 'updated_at': datetime.now(timezone.utc).isoformat(), 'state': 'stopped'})
    finally:
        lock.__exit__()


if __name__ == '__main__':
    main()
