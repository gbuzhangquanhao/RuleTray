"""Agent-only Windows tray smoke test using disposable project and state.

This initializes native menus and exercises callbacks; it is NOT visual or
physical mouse-click acceptance. No real project rules are touched.
"""
import json
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
sys.path.insert(0, str(PROJECT / '.runtime'))

from agent_task_router.core import write_json
from agent_task_router.manual import MARKER, OTHER, ManualRouter, sha
from agent_task_router.menu_app import MenuApp


def main():
    temporary_root = PROJECT / 'tests' / '.tmp'
    temporary_root.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=temporary_root) as directory:
        root = Path(directory)
        target = root / 'RULES.md'
        original = ('core\n' + MARKER + '\ncomplete default\n').encode()
        target.write_bytes(original)
        (root / 'demo.md').write_text('demo rules', encoding='utf-8')
        config = root / 'project.json'
        write_json(config, {'mode': 'manual_file', 'root': '.', 'name': 'Disposable smoke test',
                            'target_file': 'RULES.md', 'deployment_ready': True,
                            'default_is_complete': True, 'baseline_sha256': sha(original),
                            'routes': [{'id': 'demo', 'name': 'Demo task', 'docs': ['demo.md']}]})
        app = MenuApp(root / 'menu.json')
        app.controller.router_factory = lambda p: ManualRouter(p, root / 'runtime')
        app.icon.notify = lambda *args: None
        errors, steps = [], []

        def exercise():
            try:
                if not app.tray_ready.is_set():
                    app.root.after(100, exercise)
                    return
                app.choose_project(config)
                assert target.read_bytes() == original
                app.update_menu()
                assert any(item.text == 'Demo task' for item in app.icon.menu.items)
                steps.append('browse and native flat menu')
                app.select(str(config), 'demo', str(target))
                app.update_menu()
                assert app.controller.observed['state'] == 'verified'
                assert next(i for i in app.icon.menu.items if i.text == 'Demo task').checked
                steps.append('publish and native checked state')
                app.select(str(config), 'demo', str(target))
                app.select(str(config), OTHER, str(target))
                assert target.read_bytes() == original
                steps.append('repeat and exact default restore')
                assert app.root.state() == 'withdrawn'
            except Exception as exc:
                errors.append(repr(exc))
            finally:
                if app.tray_ready.is_set():
                    app.root.after(300, app.close)

        app.root.after(300, exercise)
        app.run()
        assert app.tray_ready.is_set() and len(steps) == 3 and not errors, (steps, errors)
        print(json.dumps({'native_tray_smoke': 'passed', 'steps': steps,
                          'visual_mouse_acceptance': 'not verified'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
