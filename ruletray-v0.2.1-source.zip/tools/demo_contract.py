"""Runnable illustrative contract, NOT recommended task data or production rules."""
import itertools
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agent_task_router.core import write_json
from agent_task_router.manual import ManualRouter, MARKER, OTHER, sha


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--temp-parent', type=Path, help='Optional writable parent for constrained environments')
    args = parser.parse_args()
    if args.temp_parent:
        args.temp_parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='router-contract-', dir=args.temp_parent) as directory:
        root = Path(directory)
        baseline = ('Respect authorized scope.\n' + MARKER + '\nDefault: clarify the requested outcome.\n').encode()
        (root/'RULES.md').write_bytes(baseline)
        routes = []
        for name, body in [('draft', 'Produce a draft; label uncertainty.'), ('check', 'Check the supplied draft; report evidence.')]:
            source = root/(name+'.md')
            source.write_text(body, encoding='utf-8')
            routes.append({'id': name, 'docs': [source.name], 'spec_sha256': sha(source.read_bytes()), 'spec_version': 'demo-1'})
        config = root/'project.json'
        write_json(config, {'format': 3, 'mode': 'manual_file', 'root': '.', 'target_file': 'RULES.md',
                            'routes': routes, 'baseline_sha256': sha(baseline),
                            'deployment_ready': True, 'default_is_complete': True})
        for a,b in itertools.product(['draft','check',OTHER], repeat=2):
            router = ManualRouter(config, root/'runtime')
            router.select(a)
            router.select(b)
            assert router.inspect()['route_id'] == b
        router.select(OTHER)
        assert (root/'RULES.md').read_bytes() == baseline
        print(json.dumps({'ordered_pairs': 9, 'restored': True, 'illustrative_only': True}))


if __name__ == '__main__':
    main()
