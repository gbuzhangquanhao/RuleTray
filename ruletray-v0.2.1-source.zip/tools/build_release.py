"""Explicit public source allowlist. Never recursively package the working directory."""
import argparse
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
FILES = ['.gitignore', 'README.md', 'PLAYBOOK.md', 'FRONTEND.md', 'ADAPTERS.md', 'MIGRATION.md', 'CASE-STUDY.md',
         'RELEASE-CHECKLIST.md', 'LICENSE', 'pyproject.toml', 'launch.pyw',
         'examples/project-config.template.json', 'tools/demo_contract.py', 'tools/smoke_tray.py', 'tools/build_release.py',
         'tests/test_manual.py', 'tests/test_tray_contract.py', 'tests/test_cache_observer.py',
         'tools/cache_observer.py', 'CACHE-OBSERVATION.md', 'RELEASE-NOTES.md',
         'PUBLISHING.md', 'THIRD-PARTY-NOTICES.md', 'VALIDATION.md', '.github/workflows/tests.yml']
FILES += ['agent_task_router/'+name+'.py' for name in ['__init__', 'core', 'manual', 'menu_controller', 'menu_app', 'preflight']]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    payload = {name: (ROOT/name).read_bytes() for name in FILES}
    for name, data in payload.items():
        if re.search(rb'(?<![A-Za-z0-9])[A-Za-z]:[\\/]', data) or re.search(rb'\bsk-[A-Za-z0-9]{20,}', data):
            raise ValueError('Review potential private data in '+name)
    from zipfile import ZipInfo
    with ZipFile(args.output, 'w', ZIP_DEFLATED) as archive:
        for name, data in payload.items():
            info = ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with ZipFile(args.output) as archive:
        assert set(archive.namelist()) == set(FILES)
        assert all(archive.read(name) == data for name,data in payload.items())
    print(json.dumps({'files': len(FILES), 'bytes': args.output.stat().st_size,
                      'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
