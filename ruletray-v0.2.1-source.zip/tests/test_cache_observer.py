import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('observer', Path(__file__).resolve().parents[1]/'tools/cache_observer.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class ObserverTests(unittest.TestCase):
    def setUp(self):
        sandbox = Path(__file__).resolve().parent/'.tmp'
        sandbox.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=sandbox)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.start, self.end = m.stamp('2026-11-01T00:00:00Z'), m.stamp('2026-11-04T00:00:00Z')

    def write(self, name, rows, partial=''):
        p = self.root/name
        p.write_text(''.join(json.dumps(r)+'\n' for r in rows)+partial, encoding='utf-8')
        return p

    def row(self, kind, payload, ts='2026-11-02T01:00:00Z'):
        return {'timestamp':ts,'type':kind,'payload':payload}

    def meta(self, source='vscode', project='/project'):
        return self.row('session_meta', {'id':'t','cwd':project,'source':source})

    def usage(self, rid='r', cached=60, ts='2026-11-02T01:00:01Z'):
        return self.row('token_usage_record', {'thread_id':'t','turn_id':'turn','root_turn_id':'turn','response_id':rid,'usage':{'input_tokens':100,'cached_input_tokens':cached},'thread_token_usage':{'input_tokens':99999,'cached_input_tokens':99998}},ts)

    def scan(self, paths):
        return m.read_logs(paths,'/project',self.start,self.end)

    def test_duplicate_rollovers_and_cumulative_snapshots(self):
        p = self.write('one',[self.meta(),self.usage(),self.row('event_msg',{'type':'token_count','info':{'last_token_usage':{'input_tokens':100}}})])
        q = self.write('two',[self.meta(),self.usage(),self.usage('r2')])
        rows, diag = self.scan([p,q])
        self.assertEqual(m.totals(rows)['input_tokens'],200)
        self.assertEqual(sum(r['first_observed_request'] for r in rows),1)
        self.assertEqual(diag['duplicate_records'],1)

    def test_guardian_and_other_project_excluded(self):
        a=self.write('a',[self.meta({'subagent':{'other':'guardian'}}),self.usage()])
        b=self.write('b',[self.meta(project='/another'),self.usage()])
        self.assertEqual(self.scan([a,b])[0],[])

    def test_missing_or_invalid_is_not_zero(self):
        a=self.write('a',[self.meta(),self.usage(cached=None),self.usage('bad',101),self.usage('good',0)])
        rows,diag=self.scan([a])
        self.assertEqual(len(rows),1)
        self.assertEqual(diag['missing_or_invalid_usage'],2)

    def test_partial_line_completed_next_scan(self):
        text=json.dumps(self.usage())
        a=self.write('a',[self.meta()],text[:40])
        self.assertEqual(self.scan([a])[0],[])
        with a.open('a',encoding='utf-8') as f:f.write(text[40:]+'\n')
        self.assertEqual(len(self.scan([a])[0]),1)

    def test_instruction_evidence_model_and_change(self):
        body='# AGENTS.md instructions for /project\n\n<INSTRUCTIONS>\ncore\n<!-- TASK-ROUTER:MANAGED -->\n## Active task: learn\n</INSTRUCTIONS>'
        message=self.row('response_item',{'role':'user','content':[{'text':body}]})
        context=self.row('turn_context',{'turn_id':'turn','model':'model-a'})
        a=self.write('a',[self.meta(),message,context,self.usage(),self.row('response_item',{'role':'user','content':[{'text':body.replace('learn','study')}]},'2026-11-02T02:00:00Z'),self.usage('r2',ts='2026-11-02T02:00:01Z')])
        rows,_=self.scan([a])
        self.assertEqual([r['task'] for r in rows],['learn','study'])
        self.assertEqual(rows[0]['model'],'model-a')
        self.assertNotEqual(rows[0]['rule_hash'],rows[1]['rule_hash'])
        self.assertIsNone(m.instruction_event({'role':'assistant','content':[{'text':body}]},'/project'))
        self.assertIsNone(m.instruction_event({'role':'user','content':[{'text':'quote: '+body}]},'/project'))

    def test_window_and_weighted_ratio(self):
        a=self.write('a',[self.meta(),self.usage(cached=0,ts='2026-10-31T00:00:00Z'),self.usage('r2',80)])
        rows,_=self.scan([a])
        self.assertEqual(m.totals(rows)['cache_ratio'],.8)
        self.assertEqual(m.totals(rows)['first_requests'],0)
        self.assertIsNone(m.totals([])['cache_ratio'])

    def test_lock_rejects_second_writer(self):
        with m.Lock(self.root/'lock'):
            with self.assertRaises(OSError):
                with m.Lock(self.root/'lock'):pass

    def test_comparison_requires_same_model_and_new_injection(self):
        base={'thread_id':'before','timestamp':'2026-11-01T01:00:00Z','response_id':'b','input_tokens':100,'cached_input_tokens':40,'first_observed_request':True,'model':'m','rule_hash':'old','task':'learn','task_evidence':'manual_history','observed_root_turns':1,'title':'before'}
        after=dict(base,thread_id='after',timestamp='2026-11-02T01:00:00Z',response_id='a',cached_input_tokens=60,rule_hash='new',task_evidence='injected',title='after')
        config={'observation_start':'2026-11-02T00:00:00Z','observation_end':'2026-11-04T00:00:00Z'}
        s,_,page=m.report([base,after],{},config,self.end)
        self.assertAlmostEqual(s['comparisons'][0]['cache_difference_percentage_points'],20)
        self.assertIsNone(s['causal_lift'])
        self.assertIn('<table>',page)
        after['model']='different'
        s,_,_=m.report([base,after],{},config,self.end)
        self.assertIsNone(s['comparisons'][0]['cache_difference_percentage_points'])

    def test_validation_probe_is_not_learning_lift_evidence(self):
        row={'thread_id':'probe','timestamp':'2026-11-02T01:00:00Z','response_id':'x','input_tokens':100,'cached_input_tokens':80,'first_observed_request':True,'model':'m','rule_hash':'new','task':'learn','task_evidence':'injected','observed_root_turns':1,'title':'probe','purpose':'validation'}
        config={'observation_start':'2026-11-02T00:00:00Z','observation_end':'2026-11-04T00:00:00Z'}
        summary,_,_=m.report([row],{},config,self.end)
        self.assertEqual(summary['routed_new_chat_samples'],0)
        self.assertEqual(summary['comparisons'],[])
        self.assertEqual(summary['validation_requests'],1)
        self.assertEqual(summary['totals']['requests'],1)


if __name__=='__main__':unittest.main()
