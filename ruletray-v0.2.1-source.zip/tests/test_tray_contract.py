"""Exercise menu behavior without a desktop or optional tray dependencies."""
import queue
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

import test_manual
from agent_task_router.core import RouterError, load_json, write_json
from agent_task_router.manual import ManualRouter, OTHER
from agent_task_router.menu_controller import MenuController
from agent_task_router.menu_app import MenuApp


class Item:
    def __init__(self, text, action, **options):
        self.text, self.action, self.options = text, action, options


class Menu:
    SEPARATOR = object()

    def __init__(self, *items):
        self.items = items


class TrayContractTests(unittest.TestCase):
    def setUp(self):
        test_manual.ManualTests.setUp(self)
        self.app = MenuApp.__new__(MenuApp)
        self.app.controller = MenuController(self.root / 'menu.json',
            lambda p: ManualRouter(p, self.root / ('runtime-' + p.stem)))
        self.app.controller.choose_project(self.config)
        self.app.actions = queue.Queue()
        self.app.stray = SimpleNamespace(Menu=Menu, MenuItem=Item)
        self.app.icon = SimpleNamespace(HAS_NOTIFICATION=True, notify=Mock(), title='')

    def task_item(self, text):
        return next(i for i in self.app.make_menu().items if isinstance(i, Item) and i.text == text)

    def invoke(self, item):
        item.action(None, None)
        action, args = self.app.actions.get_nowait()
        action(*args)

    def test_tasks_flattened_and_default_action_only_shows_status(self):
        menu = self.app.make_menu()
        self.assertTrue(menu.items[0].text.startswith('目标项目：'))
        self.assertIsInstance(menu.items[0].action, Menu)
        self.assertEqual([i.text for i in menu.items if isinstance(i, Item) and i.options.get('radio')],
                         ['one', 'two', '其他任务（完整默认规则）'])
        default = next(i for i in menu.items if isinstance(i, Item) and i.options.get('default'))
        default.action(None, None)
        action, args = self.app.actions.get_nowait()
        self.assertEqual(action.__name__, 'show_status')
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_checkbox_comes_from_file_and_conflict_clears_it(self):
        self.invoke(self.task_item('one'))
        self.assertTrue(self.task_item('one').options['checked'](None))
        self.target.write_bytes(self.target.read_bytes() + b'external')
        self.app.controller.refresh_status()
        self.assertFalse(self.task_item('one').options['checked'](None))
        self.assertFalse(self.task_item('其他任务（完整默认规则）').options['checked'](None))

    def test_same_task_does_not_repeat_system_notification(self):
        self.invoke(self.task_item('one'))
        self.app.icon.notify.assert_called_once()
        self.app.icon.notify.reset_mock()
        self.invoke(self.task_item('one'))
        self.app.icon.notify.assert_not_called()

    def test_delayed_old_menu_cannot_write_new_project(self):
        old_item = self.task_item('one')
        config = load_json(self.config)
        config['target_file'] = 'SECOND.md'
        second = self.root / 'second.json'
        write_json(second, config)
        (self.root / 'SECOND.md').write_bytes(self.original)
        self.app.choose_project(second)
        with self.assertRaisesRegex(RouterError, '菜单对应项目已变化'):
            self.invoke(old_item)
        self.assertEqual(self.target.read_bytes(), self.original)
        self.assertEqual((self.root / 'SECOND.md').read_bytes(), self.original)

    def test_notification_error_does_not_undo_verified_success(self):
        self.app.icon.notify.side_effect = OSError('notification blocked')
        self.invoke(self.task_item('one'))
        self.assertEqual(self.app.controller.observed['state'], 'verified')
        self.assertIn('系统通知不可用', self.app.last_result)

    def test_old_menu_rejects_changed_config_same_target(self):
        item = self.task_item('one')
        config = load_json(self.config)
        config['routes'][0]['docs'] = ['two.md']
        write_json(self.config, config)
        with self.assertRaisesRegex(RouterError, '配置已变化'):
            self.invoke(item)
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_duplicate_start_does_not_construct_another_app(self):
        from agent_task_router.menu_app import main
        with patch('agent_task_router.menu_app.SessionLock') as lock, \
             patch('agent_task_router.menu_app.MenuApp') as app, \
             patch('agent_task_router.menu_app.messagebox.showinfo') as info:
            lock.return_value.__enter__.side_effect = RouterError('already running')
            main()
            app.assert_not_called()
            info.assert_called_once()

    def test_menu_refresh_failure_does_not_stop_next_click(self):
        self.app.running = True
        self.app.root = SimpleNamespace(after=Mock())
        self.app.update_menu = Mock(side_effect=RuntimeError('native menu busy'))
        self.task_item('one').action(None, None)
        with self.assertLogs('agent_task_router.menu', level='ERROR'):
            self.app.drain()
        self.assertEqual(self.app.controller.observed['route_id'], 'one')
        self.app.root.after.assert_called_with(100, self.app.drain)
        self.app.update_menu.side_effect = None
        self.task_item('其他任务（完整默认规则）').action(None, None)
        self.app.drain()
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_poll_failure_keeps_polling(self):
        self.app.running = True
        self.app.root = SimpleNamespace(after=Mock())
        with patch.object(self.app.controller, 'refresh_status', side_effect=RuntimeError('poll failed')):
            with self.assertLogs('agent_task_router.menu', level='ERROR'):
                self.app.poll_status()
        self.app.root.after.assert_called_with(1000, self.app.poll_status)

    def test_config_change_rebuilds_default_menu_without_rule_write(self):
        self.app.running = True
        self.app.root = SimpleNamespace(after=Mock())
        self.app.menu_revision = self.app.current_menu_revision()
        self.app.update_menu = Mock()
        config = load_json(self.config)
        config['routes'][0]['name'] = 'renamed task'
        write_json(self.config, config)
        self.app.poll_status()
        self.app.update_menu.assert_called_once()
        self.assertEqual(self.target.read_bytes(), self.original)


if __name__ == '__main__':
    unittest.main()
