import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from agent_task_router.core import RouterError, write_json, load_json, SessionLock, process_alive
from agent_task_router.manual import ManualRouter, MARKER, OTHER, sha
from agent_task_router.menu_controller import MenuController


class ManualTests(unittest.TestCase):
    def setUp(self):
        temp_root = Path(__file__).resolve().parent / '.tmp'
        temp_root.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=temp_root)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.original = b'core\r\n' + MARKER.encode() + b'\r\noriginal tail\r\n'
        self.target = self.root / 'RULES.md'
        self.target.write_bytes(self.original)
        (self.root / 'one.md').write_text('# One\nrule\n', encoding='utf-8')
        (self.root / 'two.md').write_text('# Two\nother rule\n', encoding='utf-8')
        self.config = self.root / 'project.json'
        write_json(self.config, {'mode': 'manual_file', 'root': '.', 'target_file': 'RULES.md',
                                'deployment_ready': True, 'default_is_complete': True,
                                'baseline_sha256': sha(self.original),
                                'routes': [{'id': 'one', 'docs': ['one.md']},
                                           {'id': 'two', 'docs': ['two.md']}]})
        self.router = ManualRouter(self.config, self.root / 'runtime')

    def test_exact_prefix_idempotence_switch_and_restore(self):
        preview = self.router.preview('one')
        self.assertEqual(self.target.read_bytes(), self.original)
        self.router.apply('one', preview)
        self.assertTrue(self.target.read_bytes().startswith(self.original.split(b'original tail')[0]))
        self.assertEqual(self.target.read_text().count('# One'), 1)
        timestamp = self.target.stat().st_mtime_ns
        self.assertEqual(self.router.apply('one')['status'], 'unchanged')
        self.assertEqual(timestamp, self.target.stat().st_mtime_ns)
        self.router.apply('two')
        self.assertNotIn(b'# One', self.target.read_bytes())
        self.router.restore()
        self.assertEqual(self.original, self.target.read_bytes())

    def test_external_changes_block_apply_and_restore(self):
        self.router.apply('one')
        self.target.write_bytes(self.target.read_bytes() + b'external')
        for action in (lambda: self.router.apply('two'), self.router.restore):
            with self.assertRaises(RouterError):
                action()

    def test_source_change_invalidates_preview(self):
        preview = self.router.preview('one')
        (self.root / 'one.md').write_text('changed')
        with self.assertRaises(RouterError):
            self.router.apply('one', preview)
        self.assertEqual(self.original, self.target.read_bytes())

    def test_missing_duplicate_and_unterminated_marker_rejected(self):
        for data in (b'core', self.original + MARKER.encode() + b'\n', b'core\n' + MARKER.encode()):
            self.target.write_bytes(data)
            with self.assertRaises(RouterError):
                self.router.apply('one')
            self.assertEqual(data, self.target.read_bytes())

    def test_failed_write_keeps_recoverable_backup(self):
        with patch('agent_task_router.manual.atomic_write', side_effect=OSError('disk failure')):
            with self.assertRaises(OSError):
                self.router.apply('one')
        self.assertIn('pending', load_json(self.router.state_path))
        self.router.apply('two')
        self.router.restore()
        self.assertEqual(self.original, self.target.read_bytes())

    def test_crash_after_target_write_recovers(self):
        real_write = write_json
        calls = []
        def crash(path, value):
            calls.append(1)
            if len(calls) == 2:
                raise OSError('crash after target update')
            real_write(path, value)
        with patch('agent_task_router.manual.write_json', side_effect=crash):
            with self.assertRaises(OSError):
                self.router.apply('one')
        self.router.restore()
        self.assertEqual(self.original, self.target.read_bytes())

    def test_content_is_same_after_project_relocation(self):
        import shutil
        first = self.router.render('one')
        self.assertNotIn(str(self.root).encode(), first)
        other = self.root / 'relocated'
        other.mkdir()
        for name in ('one.md', 'two.md', 'project.json'):
            shutil.copyfile(self.root / name, other / name)
        self.assertEqual(first, ManualRouter(other / 'project.json').render('one'))

    def test_other_restores_complete_baseline(self):
        self.assertEqual(self.router.select(OTHER)['status'], 'unchanged')
        self.router.select('one')
        self.router.select(OTHER)
        self.assertEqual(self.target.read_bytes(), self.original)
        self.router.select('two')
        self.router.select(OTHER)
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_unreviewed_or_wrong_baseline_cannot_publish(self):
        for override in ({'deployment_ready': False}, {'default_is_complete': False}, {'baseline_sha256': 'wrong'}):
            config = load_json(self.config)
            config.update(override)
            write_json(self.config, config)
            router = ManualRouter(self.config, self.root / 'runtime')
            for task in ('one', OTHER):
                with self.assertRaises(RouterError):
                    router.select(task)
            self.assertEqual(self.original, self.target.read_bytes())

    def test_selection_immediately_applies_and_failure_keeps_previous(self):
        c = MenuController(self.root / 'menu.json', lambda path: ManualRouter(path, self.root / 'runtime'))
        c.choose_project(self.config)
        c.select(str(self.config), 'one')
        self.assertIn(b'# One', self.target.read_bytes())
        self.assertEqual(c.task(), 'one')
        self.target.write_bytes(self.target.read_bytes() + b'external edit')
        with self.assertRaises(RouterError):
            c.select(task='two')
        self.assertEqual(c.task(), 'one')
        self.assertEqual(load_json(c.path)['tasks'][str(self.config)], 'one')
        self.assertEqual(c.observed['state'], 'conflict')
        self.assertIsNone(c.observed['route_id'])

    def test_controller_restart_does_not_write_rules(self):
        c = MenuController(self.root / 'menu.json', lambda path: ManualRouter(path, self.root / 'runtime'))
        c.choose_project(self.config)
        c.select(str(self.config), 'one')
        before = self.target.stat().st_mtime_ns
        again = MenuController(c.path)
        self.assertEqual(again.task(), 'one')
        self.assertEqual(before, self.target.stat().st_mtime_ns)

    def test_lock_contention_and_release(self):
        path = self.root / 'test.lock'
        with SessionLock(path):
            with self.assertRaises(RouterError):
                with SessionLock(path):
                    pass
        with SessionLock(path):
            pass

    def test_process_query_does_not_signal(self):
        import os
        with patch('os.kill', side_effect=AssertionError('must not signal Windows process')):
            if os.name == 'nt':
                self.assertTrue(process_alive(os.getpid()))

    def test_empty_docs_or_embedded_marker_rejected(self):
        config = load_json(self.config)
        for docs in ([], ['empty.md'], ['embedded.md']):
            (self.root / 'empty.md').write_text('  ')
            (self.root / 'embedded.md').write_text(MARKER)
            config['routes'][0]['docs'] = docs
            write_json(self.config, config)
            with self.assertRaises(RouterError):
                ManualRouter(self.config, self.root / 'runtime').select('one')
        self.assertEqual(self.original, self.target.read_bytes())

    def test_project_switch_is_read_only_and_task_is_explicit(self):
        second = self.root / 'second.json'
        config = load_json(self.config)
        config['target_file'] = 'SECOND.md'
        write_json(second, config)
        (self.root / 'SECOND.md').write_bytes(self.original)
        c = MenuController(self.root / 'menu.json', lambda path: ManualRouter(path, self.root / ('runtime-' + path.stem)))
        c.choose_project(self.config)
        c.select(str(self.config), 'one')
        first_bytes = self.target.read_bytes()
        c.choose_project(second)
        self.assertIsNone(c.task())
        self.assertEqual(c.observed['route_id'], OTHER)
        self.assertEqual((self.root / 'SECOND.md').read_bytes(), self.original)
        with self.assertRaises(RouterError):
            c.select(str(second))
        with self.assertRaisesRegex(RouterError, '菜单对应项目已变化'):
            c.select(str(self.config), 'one')
        c.select(task='two')
        c.choose_project(self.config)
        self.assertEqual(c.task(), 'one')
        self.assertEqual(self.target.read_bytes(), first_bytes)
        c.choose_project(second)
        self.assertEqual(c.task(), 'two')
        self.assertIn(b'# Two', (self.root / 'SECOND.md').read_bytes())

    def controller(self):
        c = MenuController(self.root / 'menu.json', lambda path: ManualRouter(path, self.root / 'runtime'))
        c.choose_project(self.config)
        return c

    def test_post_write_journal_failure_reports_actual_task_and_recovers(self):
        c = self.controller()
        real_write = write_json
        calls = []
        def fail_final(path, value):
            calls.append(1)
            if len(calls) == 2:
                raise OSError('journal final write failed')
            real_write(path, value)
        with patch('agent_task_router.manual.write_json', side_effect=fail_final):
            with self.assertRaisesRegex(RouterError, '磁盘已是所选任务'):
                c.select(task='one')
        self.assertEqual(c.observed['state'], 'pending')
        self.assertEqual(c.observed['route_id'], 'one')
        before = self.target.read_bytes()
        state_before = self.router.state_path.read_bytes()
        again = self.controller()
        self.assertEqual(again.observed['route_id'], 'one')
        self.assertEqual(self.router.state_path.read_bytes(), state_before)
        self.assertEqual(self.target.read_bytes(), before)
        again.select(task='one')
        self.assertEqual(again.observed['state'], 'verified')
        again.select(task=OTHER)
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_failure_before_target_write_reports_not_written(self):
        c = self.controller()
        with patch('agent_task_router.manual.atomic_write', side_effect=OSError('disk full')):
            with self.assertRaisesRegex(RouterError, '未写入'):
                c.select(task='one')
        self.assertEqual(c.observed['route_id'], OTHER)
        self.assertEqual(c.observed['pending_phase'], 'not_written')
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_preference_failure_does_not_hide_successful_file_change(self):
        c = self.controller()
        with patch('agent_task_router.menu_controller.write_json', side_effect=OSError('preferences unavailable')):
            with self.assertRaisesRegex(RouterError, '菜单偏好未保存'):
                c.select(task='two')
        self.assertEqual(c.observed['state'], 'verified')
        self.assertEqual(c.observed['route_id'], 'two')
        again = MenuController(c.path, c.router_factory)
        self.assertIsNone(again.task())  # old preference, actual file takes precedence
        self.assertEqual(again.observed['route_id'], 'two')

    def test_source_change_is_reported_without_silent_writes(self):
        c = self.controller()
        c.select(task='one')
        old = self.target.read_bytes()
        (self.root / 'one.md').write_text('new rules')
        c.refresh_status()
        self.assertEqual(c.observed['state'], 'stale')
        self.assertEqual(self.target.read_bytes(), old)
        c.select(task='one')
        self.assertEqual(c.observed['state'], 'verified')
        self.assertIn(b'new rules', self.target.read_bytes())

    def test_changed_target_rejects_old_menu_action(self):
        c = self.controller()
        old_target = str(self.target)
        config = load_json(self.config)
        config['target_file'] = 'CHANGED.md'
        write_json(self.config, config)
        with self.assertRaisesRegex(RouterError, '目标文件已变化'):
            c.select(task='one', expected_target=old_target)
        self.assertEqual(self.target.read_bytes(), self.original)
        self.assertFalse((self.root / 'CHANGED.md').exists())

    def test_corrupt_backup_blocks_new_writes_and_status(self):
        self.router.select('one')
        state = load_json(self.router.state_path)
        state['original_b64'] = 'damaged backup'
        write_json(self.router.state_path, state)
        current = self.target.read_bytes()
        self.assertEqual(self.router.inspect()['state'], 'unknown')
        with self.assertRaisesRegex(RouterError, '恢复备份损坏'):
            self.router.select('two')
        self.assertEqual(self.target.read_bytes(), current)
        write_json(self.router.state_path, [])
        with self.assertRaisesRegex(RouterError, '事务状态格式损坏'):
            self.router.select('two')
        self.assertEqual(self.target.read_bytes(), current)

    def test_target_cannot_be_its_own_source(self):
        config = load_json(self.config)
        config['routes'][0]['docs'] = ['RULES.md']
        write_json(self.config, config)
        with self.assertRaises(RouterError):
            ManualRouter(self.config).render('one')

    def test_total_limit_and_bad_section_fail_closed(self):
        config = load_json(self.config)
        config['max_inline_chars'] = 1
        write_json(self.config, config)
        with self.assertRaises(RouterError):
            ManualRouter(self.config).render('one')

    def test_single_document_contract(self):
        config = load_json(self.config)
        for docs in (['one.md', 'one.md'], ['one.md', 'two.md'], [{'path': 'one.md'}], 'one.md', []):
            config['routes'][0]['docs'] = docs
            write_json(self.config, config)
            with self.assertRaisesRegex(RouterError, '一个完整规范'):
                ManualRouter(self.config)

    def test_review_pin_blocks_drift_but_allows_restore(self):
        config = load_json(self.config)
        config['format'] = 3
        config['routes'][0]['spec_sha256'] = sha((self.root / 'one.md').read_bytes())
        write_json(self.config, config)
        router = ManualRouter(self.config, self.root / 'runtime')
        router.select('one')
        current = self.target.read_bytes()
        (self.root / 'one.md').write_text('unapproved rules')
        with self.assertRaisesRegex(RouterError, '批准指纹'):
            router.select('one')
        self.assertEqual(current, self.target.read_bytes())
        with self.assertRaisesRegex(RouterError, '批准指纹'):
            router.select('two')
        router.select(OTHER)
        self.assertEqual(self.original, self.target.read_bytes())

    def test_disable_conflict_and_retry(self):
        c = self.controller()
        c.select(task='one')
        plan = c.preview_disable()
        before = self.target.read_bytes()
        self.target.write_bytes(before + b'external')
        results = c.disable(plan)
        self.assertIn('error', results[0])
        self.assertFalse(c.enabled)
        self.assertTrue(c.settings['pending_restore'])
        with self.assertRaisesRegex(RouterError, '停用'):
            c.select(task='two')
        self.assertEqual(before + b'external', self.target.read_bytes())
        self.target.write_bytes(before)
        c.disable(c.preview_disable())
        self.assertEqual(self.original, self.target.read_bytes())
        self.assertFalse(c.settings['pending_restore'])
        c.enable()
        self.assertEqual(self.original, self.target.read_bytes())
        c.select(task='two')

    def test_disable_config_drift_and_intent_failure(self):
        c = self.controller()
        c.select(task='one')
        plan = c.preview_disable()
        with patch('agent_task_router.menu_controller.write_json', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                c.disable(plan)
        self.assertTrue(c.enabled)
        self.assertIn(b'# One', self.target.read_bytes())

        config = load_json(self.config)
        config['name'] = 'changed'
        write_json(self.config, config)
        self.assertIn('error', c.disable(plan)[0])
        self.assertIn(b'# One', self.target.read_bytes())

    def test_disable_multiple_projects_reports_partial_failure(self):
        c = MenuController(self.root / 'multi-menu.json', lambda p: ManualRouter(p, self.root / ('state-'+p.stem)))
        c.choose_project(self.config)
        c.select(task='one')
        config = load_json(self.config)
        config['target_file'] = 'SECOND.md'
        second = self.root / 'second.json'
        write_json(second, config)
        target = self.root / 'SECOND.md'
        target.write_bytes(self.original)
        c.choose_project(second)
        c.select(task='two')
        first = self.target.read_bytes()
        self.target.write_bytes(first + b'external')
        results = c.disable(c.preview_disable())
        self.assertIn('error', results[0])
        self.assertNotIn('error', results[1])
        self.assertEqual(target.read_bytes(), self.original)
        self.assertEqual(self.target.read_bytes(), first + b'external')
        self.assertEqual(len(c.settings['pending_restore']), 1)

    def test_preflight_reports_line_numbers(self):
        from agent_task_router.preflight import inspect_config
        (self.root / 'one.md').write_text('# One\nRead rules/another.md first.\n', encoding='utf-8')
        report = inspect_config(self.config)
        self.assertEqual(report['routes'][0]['warnings'][0]['line'], 2)
        self.assertEqual(report['config_sha256'], sha(self.config.read_bytes()))

    def test_section_selector_rejected(self):
        config = load_json(self.config)
        config['max_inline_chars'] = 10000
        config['routes'][0]['docs'] = [{'path': 'one.md', 'start_heading': '# One', 'end_heading': '# Missing'}]
        write_json(self.config, config)
        with self.assertRaises(RouterError):
            ManualRouter(self.config).render('one')


if __name__ == '__main__':
    unittest.main()
