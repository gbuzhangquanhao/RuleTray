"""Double-click to launch without a console."""
import tkinter.messagebox as messagebox
import sys
from pathlib import Path

# Optional project-local dependencies prepared by the adapting Agent.
runtime = Path(__file__).resolve().parent / '.runtime'
if runtime.is_dir():
    sys.path.insert(0, str(runtime))
try:
    from agent_task_router.menu_app import main
    main()
except Exception as exc:
    messagebox.showerror("Task Router", str(exc))
